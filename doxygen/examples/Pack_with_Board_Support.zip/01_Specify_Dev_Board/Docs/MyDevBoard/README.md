# MyDevBoard User's Guide

This Markdown file can be used to describe the board is more detail and to add additional information around
its usage. Web pages should display this file in the context of the development board.
Here is an example: [EVKB-IMXRT1050_MDK](https://www.keil.arm.com/boards/nxp-evkb-imxrt1050-mdk-rev-a1-126523e/guide/)